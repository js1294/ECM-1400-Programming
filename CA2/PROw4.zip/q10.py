def squeeze(L: list[int]) -> list[int]:
    """Return argument list L with matching adjacent items removed"""
    previous = None
    for i in L:
        if i == previous:
            L.remove(i)
        previous = i
    return L

# inspect the test value
print(squeeze([1, 2, 2, 3]))
# automatically test the outcome
if squeeze([1, 2, 2, 3]) == [1, 2, 3]:
    print('Functions works correctly!')
else:
    print('Error in squeeze')
