def factorial_less_than_1m(num: int) -> int:
    """Return the factorial product of the integer argument num

    Return None if the product exceeds 1 million. """
    total = 1
    for i in range(1,num):
        total = total * i
        if total > 1_000_000:
            return None
    return total

test_cases = [3, 7, 9, 32, 243]
for test in test_cases:
    print(factorial_less_than_1m(test))
