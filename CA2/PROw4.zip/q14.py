def sumpowers(numbers: list[int], power: int) -> int:
    """
    Return the sum of the numbers raised to the power.
    """
    sum = 0
    for n in numbers:
        sum = sum + n**power
    return sum

def terms(big: int, p: int):
    """
    Return the number of terms needed for sumpower(terms, p) to exceed big
    """
    terms = 0
    while sumpowers(range(terms), p) <= big:
        terms = terms + 1
    return terms

# Demonstration and check
p=3
for big in [100, 1000, 10000, 1000000]:
    n = terms(big, p)
    print("Number of terms for sum to exceed", big, "is", n, "\t", sumpowers(range(n), p))
