import typing

def odd_even(L: list) -> tuple[int, int]:
    """
    Return the sum of all even and all odd integers in the argument list L
    """
    odd_sum = 0
    even_sum = 0
    for each_number in L:
        if not isinstance(each_number, int):
            print('function only works with integers -', each_number, 'failed')
            continue #this defensive programming step skips the remaining loop
        if odd(each_number):
            odd_sum += each_number
        else:
            even_sum += each_number
    return even_sum, odd_sum

def odd(number: int) -> bool:
    """
    Return a True if number is odd and False if it's even
    """
    if number%2 == 1:
        return True
    return False

L = [1, 42, -3, 2.4, 'invalid input']
odd_sum, even_sum = odd_even(L)
print(odd_sum, even_sum)
