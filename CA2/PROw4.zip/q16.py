# Draw spirals with turtles
from exturtle import *
def rspiral(t, D=20, theta=85, alpha=1.1, R=300):
    """
    Draw a spiral with turtle t.
    D: The initial distance to move before turning
    theta: Angle to turn
    alpha: Factor by which to increase alpha
    R: Maximum radius: turtle stops when it exceeds
    a distance R from the start
    """
    xstart = xcor(t)     # Centre of the spiral
    ystart = ycor(t)
    x = xstart
    y = ystart
    while (x-xstart)**2 + (y-ystart)**2 < R*R:
      forward(t, D)
      right(t, theta)
      D = D*alpha
      x = xcor(t)
      y = ycor(t)



bob = Turtle()
color(bob, "blue")
width(bob, 3)

rspiral(bob, 2, 10, 1.01, 300)

mainloop()
