def merge(queue_1: list[int], queue_2: list[int]) -> list[int]:
    """Returns a merged list of items from two lists

    Lists are merged from start to finish selecting the smallest value in the
    first position of each list
    Keyword arguments:
    queue_1 -- first ordered list of integers
    queue_2 -- second ordered list of integers
    """
    result = []
    while queue_1 and queue_2:
        if queue_1[0] > queue_2[0]:
            result.append(queue_2.pop(0))
        else:
            result.append(queue_1.pop(0))
    #add remaining elements from either list
    result.extend(queue_1)
    result.extend(queue_2)
    return result

print( merge([1, 5, 6, 7], [2, 3, 8]) )
