def terms(big: int, p: int):
    """
    Return the number of terms needed for sumpower(terms, p) to exceed big.
    Also returns the sum that first exceeded big.
    """
    terms = 1
    sum = 0
    while sum <= big:
      sum = sum + terms**p
      terms = terms + 1
    return terms, sum

# Demonstration and check
p=3
for big in [100, 1000, 10000, 1000000]:
    n, s = terms(big, p=p)
    print("Number of terms for sum to exceed", big, "is", n, "\t", s)
