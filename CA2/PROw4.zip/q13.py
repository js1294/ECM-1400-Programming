
def sumpowers(numbers: list[int], power: int) -> int:
    """
    Return the sum of the numbers raised to the power.
    """
    sum = 0
    for n in numbers:
        sum = sum + n**power
    return sum

# Try it
for p in range(11):
    Sp = sumpowers(list(range(10)), p)
    print(p, Sp)
