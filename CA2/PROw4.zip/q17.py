def fracsum(n: int):
    """
    Return the sum of 1/2^i for i = 0 .... n-1
    """
    sum = 0
    for i in range(n):
      sum = sum + 1/2**i
    return sum

# Try a few cases. As the number of terms
# becomes large the sum should converge to 2.

for n in [1, 2, 3, 10, 20, 30, 40, 100]:
    S = fracsum(n)
    print("Sum to", n, "terms is", S)
