def odd(number: int) -> bool:
    """
    Return a True if number is odd and False if it's even
    """
    if number%2 == 1:
        return True
    return False

# Check it
oddeven = list(range(20))

for i in oddeven:
    print(i, 'odd: ', odd(i))
