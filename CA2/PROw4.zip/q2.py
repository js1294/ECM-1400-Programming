def yesno(prompt: str) -> bool:
    """The function converts yes no answers into True and False

    If the user enters Y, y, yes, YES the function returns True and
    N, n, no or NO the function returns False
    keyword argument:
    prompt -- the string containing the question for user to respond"""
    user_input = ''
    while user_input not in ['Y', 'y', 'yes', 'YES', 'N', 'n', 'no', 'NO']:
        user_input = input(prompt)
    if user_input in ['Y', 'y', 'yes', 'YES']:
        return True
    else:
        return False

if yesno('Do you like programming?'):
    print('Fantastic!')
