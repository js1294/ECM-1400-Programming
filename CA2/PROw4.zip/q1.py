"""This module answers q1 of workshop 4 using demoing the two while idioms"""
def input_num() -> int:
    """Sum user input numbers until q or Q is entered"""
    sum = 0
    while True:
        user_input = input('Please input a number')
        if user_input.lower() == 'q':
            break
        sum += int(user_input)
    return sum

def input_num_alternative() -> int:
    """Sum user input numbers until q or Q is entered"""
    sum = 0
    #note the conditional variables have to be declared upfront
    user_input = input('Please input a number')
    while user_input.lower() != 'q':
        sum += int(user_input)
        user_input = input('Please input a number')
    return sum

print('sum of numbers entered...',input_num())
print('sum of numbers entered...',input_num_alternative())
