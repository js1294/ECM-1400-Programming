"""Note this module doesn't use functions so would not be testable"""
total = 10    # Total number of bottles

for n in range(total):
    bottles = total - n  # Bottles left on the wall
    print(bottles, "green bottles hanging on the wall,")
    print(bottles, "green bottles hanging on the wall,")
    print("and if one green bottle should accidentally fall,")
    print("they'll be", bottles-1, "green bottles hanging on the wall.")
    print()

print('All gone')

#START AGAIN

total = 10    # Total number of bottles

# Here range(total, 0, -1) makes the loop variable take the values:
# total, total-1, ..., 1  which is more natural for counting down
for bottles in range(total, 0, -1):
    print(bottles, "green bottles hanging on the wall,")
    print(bottles, "green bottles hanging on the wall,")
    print("and if one green bottle should accidentally fall,")
    print("they'll be", bottles-1, "green bottles hanging on the wall.")
    print()

print('All gone')
