def last_digit(number: int) -> int:
    """Return the last digit of the integer argument number.

    The last digit is the remainder after division by 10. If the number is
    negative it will be made positive before applying the modulus operator.
    """
    if number < 0:
        number = -number
    return number % 10

def first_digit(number: int) -> int:
    """Return the first digit of the integer argument number.

    The first digit of 38 is the number of 10s in 38; the first digit of 657
    is the number of hundreds in 657, and so on. So the idea here is to loop,
    dividing n by larger and larger powers of ten until the e result is less
    than 10.
    """
    if number < 0:
        number = -number
    d = 0
    while number // 10**d >= 10:
      d = d + 1
    return number // 10**d

# Test
for n in [0, 1, 12, 99, 100, 101, 657, -1, -3456]:
    print('The first digit of', n, 'is', first_digit(n))
    print('The last digit of', n, 'is', last_digit(n))
