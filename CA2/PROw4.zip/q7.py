def printn(what, number):
    """Print the argument what number times"""
    for i in range(number):
        print(what)
    return None

# Use it
printn("Hello there", 4)

printn(len("This is a long string")**3, 6)
