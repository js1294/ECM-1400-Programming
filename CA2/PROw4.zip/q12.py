def contains(word: str, letters: str) -> bool:
    """
    Return True if word contains any of the characters in string
    """
    for char in letters:
      if char in word:
          return True
    # None of the characters were in the word, so return False
    return False

def filter_forbidden(words: list[str], forbidden: str = "aiou") -> list[str]:
    """
    Return words list that don't contain letters in the forbidden string

    Keyword arguments:
    words -- the list of words to be filtered
    forbidden --  the letters that are forbidden
    """
    allowed = []
    for word in words:
        if not contains(word, forbidden):
            allowed.append(word)
    return allowed

# Read the words and filter them
lines = open('words.txt', 'r').readlines()

# Remove the trailing whitespace with strip()
words = []
for line in lines:
    words.append(line.strip())

# Get the allowed words
vowels = 'aeiou'
allowed = filter_forbidden(words, vowels)
print('There are', len(allowed), 'words that do not include', vowels)
