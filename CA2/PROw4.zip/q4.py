def tax_owed(income: float) -> float:
    """
    Return the amount of tax owed by someone with the given income.

    The brackets for income are set at 11,000 43,000 and 150,000
    Keyword argument:
    income -- this is a single income floating point value to allow for pence
    """
    if income < 11_000:
      rate = 0
    elif income < 43_000:
      rate = 30
    elif income < 150_000:
      rate = 40
    else:
      rate = 55
    return rate*income/100

# Try it on a few incomes that are easy to check

for pay in [10000, 20000, 100000, 200000]:
    print('Income:', pay, 'Tax:', tax_owed(pay))
print()

# Ask the user for an income and print the tax owed

income = input('Enter your income ')
income = float(income)
print('With an income of', income, 'you would pay', tax_owed(income), 'in tax')
