from ex6 import arrival
from ex6 import next_patient

def test_next_patient():
    queue = ["David", "Matt"]
    next_patient(1)
    assert queue == ["Matt"]

def test_arrival():
    queue = ["David", "Matt"]
    arrival("Ronaldo")
    assert queue == ["David", "Matt","Ronaldo"]
